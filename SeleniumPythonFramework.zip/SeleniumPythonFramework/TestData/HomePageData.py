"""
Demonstrating simple Data Driven Test

Usage :
-> All the input data related to HomePage should be here

INSTRUCTIONS :
1. var name :
-> keep it similar to test case method and concatenate with "_data" to easy readability

"""


class HomePageData:

        test_HomePage_data = [{"firstname": "rakesh", "lastname": "eshwar", "gender": "Male"},
                              {"firstname": "rakhitha", "lastname": "shetty", "gender": "Female"}]
